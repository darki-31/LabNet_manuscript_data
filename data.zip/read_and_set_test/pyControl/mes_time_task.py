from pyControl.utility import *
from devices import *


p_in  = Digital_input('Y7', rising_event='p_on', falling_event='p_off')
p_out = Digital_output('Y8')

# States and events.

states = ['on_state',
          'off_state']

events = ['p_on', 'p_off']

initial_state = 'on_state'
        
# Define behaviour. 

def on_state(event):
    if event == 'entry':
        p_out.off()
    elif event == 'p_on':
        goto_state('off_state')

def off_state(event):
    if event == 'entry':
        p_out.on()
    elif event == 'p_off':
        goto_state('on_state')

def run_end():  # Turn off hardware at end of run.
    p_out.off()